
import React, { useState, useCallback } from 'react';
import { QRScanner } from './components/QRScanner';
import { Button } from './components/Button';
import { Card } from './components/Card';
import { saveToSheet } from './services/googleSheetService';
import { ScannedEntry } from './types';
import { CheckCircleIcon, ExclamationTriangleIcon, QrCodeIcon, SheetIcon, SpinnerIcon } from './components/icons';

const App: React.FC = () => {
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scannedData, setScannedData] = useState<string | null>(null);
  const [savedEntries, setSavedEntries] = useState<ScannedEntry[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleScanSuccess = useCallback((decodedText: string) => {
    setScannedData(decodedText);
    setIsScanning(false);
    setError(null);
  }, []);

  const handleScanError = useCallback((errorMessage: string) => {
    // We can ignore common errors or log them if needed
    // console.error(`QR Scan Error: ${errorMessage}`);
  }, []);

  const handleSaveToSheet = async () => {
    if (!scannedData) return;

    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const newEntry: ScannedEntry = {
        timestamp: new Date().toISOString(),
        data: scannedData,
      };
      await saveToSheet(newEntry);
      setSavedEntries(prevEntries => [newEntry, ...prevEntries]);
      setScannedData(null);
      setSuccessMessage('Data successfully saved to Google Sheet!');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
      setTimeout(() => setSuccessMessage(null), 4000);
      setTimeout(() => setError(null), 4000);
    }
  };

  const startScanning = () => {
    setScannedData(null);
    setError(null);
    setSuccessMessage(null);
    setIsScanning(true);
  };
  
  const stopScanning = () => {
    setIsScanning(false);
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col items-center p-4 sm:p-6">
      <header className="w-full max-w-4xl text-center mb-8">
        <h1 className="text-4xl sm:text-5xl font-bold text-slate-900 mb-2 flex items-center justify-center gap-3">
          <QrCodeIcon className="w-10 h-10 text-primary" /> QR to Sheet
        </h1>
        <p className="text-slate-600">Scan a QR code and save the data to a Google Sheet instantly.</p>
      </header>

      <main className="w-full max-w-md">
        <Card>
          {!isScanning && !scannedData && (
            <div className="text-center p-8">
               <QrCodeIcon className="w-24 h-24 mx-auto text-slate-300 mb-6"/>
               <h2 className="text-xl font-semibold mb-4">Ready to Scan</h2>
              <Button onClick={startScanning} className="w-full">
                Start Scanning
              </Button>
            </div>
          )}

          {isScanning && (
            <div>
              <QRScanner 
                onScanSuccess={handleScanSuccess} 
                onScanError={handleScanError} 
              />
              <Button onClick={stopScanning} variant="secondary" className="w-full mt-4">
                Cancel
              </Button>
            </div>
          )}

          {scannedData && !isLoading && (
            <div className="p-6 text-center">
              <CheckCircleIcon className="w-16 h-16 text-success mx-auto mb-4" />
              <h2 className="text-xl font-semibold mb-2">Scan Successful!</h2>
              <p className="bg-slate-100 p-3 rounded-lg text-sm text-slate-700 break-all mb-6 font-mono">{scannedData}</p>
              <div className="flex gap-4">
                <Button onClick={startScanning} variant="secondary" className="flex-1">Scan Again</Button>
                <Button onClick={handleSaveToSheet} className="flex-1">
                  <SheetIcon className="w-5 h-5 mr-2" />
                  Save to Sheet
                </Button>
              </div>
            </div>
          )}
          
          {isLoading && (
             <div className="flex flex-col items-center justify-center p-8 min-h-[200px]">
                <SpinnerIcon className="w-12 h-12 text-primary"/>
                <p className="mt-4 text-slate-600">Saving to Google Sheet...</p>
             </div>
          )}

        </Card>
        
        {error && (
            <div className="mt-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative flex items-center gap-3" role="alert">
              <ExclamationTriangleIcon className="w-5 h-5"/>
              <span className="block sm:inline">{error}</span>
            </div>
        )}
        {successMessage && (
            <div className="mt-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg relative flex items-center gap-3" role="alert">
              <CheckCircleIcon className="w-5 h-5"/>
              <span className="block sm:inline">{successMessage}</span>
            </div>
        )}

        {savedEntries.length > 0 && (
          <div className="mt-8">
            <h3 className="text-lg font-semibold mb-4 text-slate-700">Recently Saved Entries</h3>
            <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
              {savedEntries.map((entry, index) => (
                <div key={index} className="bg-white p-3 rounded-lg shadow-sm">
                  <p className="text-sm text-slate-800 break-all font-mono">{entry.data}</p>
                  <p className="text-xs text-slate-500 mt-1">{new Date(entry.timestamp).toLocaleString()}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
