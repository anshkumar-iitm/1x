
import React, { useEffect, useRef } from 'react';
import { Html5Qrcode, Html5QrcodeScannerState } from 'html5-qrcode';
import type { QrCodeSuccessCallback, QrCodeErrorCallback } from 'html5-qrcode/esm/core';

interface QRScannerProps {
  onScanSuccess: QrCodeSuccessCallback;
  onScanError: QrCodeErrorCallback;
}

const QR_READER_ID = 'qr-code-reader';

export const QRScanner: React.FC<QRScannerProps> = ({ onScanSuccess, onScanError }) => {
  const scannerRef = useRef<Html5Qrcode | null>(null);

  useEffect(() => {
    scannerRef.current = new Html5Qrcode(QR_READER_ID);
    const html5Qrcode = scannerRef.current;

    const startScanner = async () => {
      try {
        await html5Qrcode.start(
          { facingMode: "environment" },
          {
            fps: 10,
            qrbox: { width: 250, height: 250 },
            aspectRatio: 1.0,
          },
          onScanSuccess,
          onScanError
        );
      } catch (err) {
        console.error("Failed to start QR scanner", err);
        onScanError(err instanceof Error ? err.message : String(err));
      }
    };

    startScanner();

    return () => {
      const cleanupScanner = async () => {
        if (html5Qrcode && html5Qrcode.getState() === Html5QrcodeScannerState.SCANNING) {
          try {
            await html5Qrcode.stop();
          } catch (err) {
            console.error("Failed to stop QR scanner gracefully", err);
          }
        }
      };
      cleanupScanner();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onScanSuccess, onScanError]);

  return (
    <div id={QR_READER_ID} className="w-full border-4 border-slate-200 rounded-lg overflow-hidden"></div>
  );
};
