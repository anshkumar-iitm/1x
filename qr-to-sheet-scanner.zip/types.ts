
/**
 * Represents a single entry that has been scanned and is ready to be saved.
 */
export interface ScannedEntry {
  /** The ISO 8601 timestamp of when the QR code was scanned. */
  timestamp: string;
  /** The data content decoded from the QR code. */
  data: string;
}
