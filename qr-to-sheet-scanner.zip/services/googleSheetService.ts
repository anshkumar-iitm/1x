
import { ScannedEntry } from '../types';

// IMPORTANT: Replace this URL with your actual Google Sheets API endpoint.
// You can get this from services like Sheet.best, Sheety, or by deploying your own Google Apps Script.
// The structure of your sheet should have columns named 'timestamp' and 'data'.
const GOOGLE_SHEET_API_URL = 'https://sheet.best/api/sheets/YOUR-API-KEY-HERE';

/**
 * Saves a new scanned entry to the configured Google Sheet.
 * @param entry - The ScannedEntry object containing the timestamp and data.
 * @throws Will throw an error if the network request fails or the API returns an error.
 */
export const saveToSheet = async (entry: ScannedEntry): Promise<void> => {
  if (GOOGLE_SHEET_API_URL.includes('YOUR-API-KEY-HERE')) {
    throw new Error('Google Sheet API URL is not configured. Please update it in services/googleSheetService.ts');
  }

  try {
    const response = await fetch(GOOGLE_SHEET_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(entry),
    });

    if (!response.ok) {
      // Try to get a more specific error message from the API response body
      const errorData = await response.json().catch(() => null);
      const errorMessage = errorData?.message || `Failed to save data. Server responded with status: ${response.status}`;
      throw new Error(errorMessage);
    }
    // The request was successful. The response body might be useful, but for now, we don't need it.
  } catch (error) {
    console.error('Error saving to Google Sheet:', error);
    if (error instanceof Error) {
        throw new Error(`Network error or API issue: ${error.message}`);
    }
    throw new Error('An unknown error occurred while trying to save to the sheet.');
  }
};
